// Author: Sean Allen

//CSCI 221 Homework 5: Griddle Pi

// Compute pi using a Monte-Carlo-style deterministic grid method.

// Zero is the first point, so we only go out to N-1 on each axis.
//   Thus the step size is 1/(N-1).

// The circle is in the first quadrant, centered at (.5, .5), with
//   radius equal to .5.

// The square is also in the first quadrant, with side length 1.

#include <iostream>

constexpr double gridpi (int N) {
    
    // number of points inside the circle or on the edge
    int count = 0;

    for (int i=0; i<N; ++i)
        for (int j=0; j<N; ++j)
            // equation for the circle
            if ( (1.*i/(N-1)-.5)*(1.*i/(N-1)-.5) + (1.*j/(N-1)-.5)*(1.*j/(N-1)-.5) <= .25 ) 
                // count points inside or on the edge of the circle
                ++count;

    // return pi estimate
    return 4.*count/((N-1)*(N-1));
}

// driver function to print pi estimate for given N
int main () {
    int N = 10000;
    std::cout << gridpi(N) << std::endl;
}
