Sean Allen

CSCI 221 Homework 5: Griddle Pi

Question 1:

N       Pi          Runtime (in seconds)    Runtime with constexpr
10      2.96296     .008                    .009
100     3.12948     .008                    .009
1000    3.14134     .015                    .015
10000   3.14158     .511                    .512


Question 2:

    Runtime Complexity: o(N^2)      (since there are two for loops)

    The asymptotic runtime should increase by two orders of magnitude when N is
    increased by a factor of 10. We see this in the data above, for large N.
    When N changes from 1000 to 10000, the runtime increases by two orders of
    magnitude.

Question 3:
    constexpr did not affect the runtimes shown by the time command (I DID compile correctly).
    However, compile time seems to take longer when constexpr is used, especially for N=10000.




