// Sean Allen
// CSCI HW 6

#include "tree.hh"

// create a tree by initializing root node

tree_ptr_t create_tree( const key_t& key,
                        const value_t& value,
                        tree_ptr_t left,
                        tree_ptr_t right) {
    tree_ptr_t new_tree = new Tree; 
    new_tree->key_ = key;
    new_tree->value_ = value;
    new_tree->left_ = left; 
    new_tree->right_ = right;
    return new_tree;
}

// recursively deallocate dynamic memory for each node in tree

void destroy_tree(tree_ptr_t tree) {
    if (tree!=nullptr){
        if (tree->left_!=nullptr)
            destroy_tree(tree->left_);
        if (tree->right_!=nullptr)
            destroy_tree(tree->right_);
        delete tree;
    } 
}

// a helpful structure for path_to

struct pair {
    std::string path = "";
    bool found = false;
};

// A helper function for path_to, recursively checks nodes and their children,
//  until the (leftmost) correct key is found. Then passes the correct path back
//  up.

pair path_to_helper(tree_ptr_t tree, key_t key, std::string path) {

    // initialize a struct to hold the path and the boolean "found" status
    pair p;

    // if current node is not null... 
    if (tree!=nullptr) {

        // if current node has the right key...
        if (tree->key_==key) {
            // save the path
            p.path = path;
            // change the "found" status
            p.found = true;
            // return the path / "found" status pair
            return p;
        }

        // otherwise check the left key (recursively) ...
        p = path_to_helper(tree->left_, key, path + "L"); 

        // ...and if found return p
        if (p.found) return p;

        // otherwise check the right key (recursively) ...
        p = path_to_helper(tree->right_, key, path + "R"); 

        // ...and if found return p
        if (p.found) return p;
    
        // otherwise ...
        p.path = path;
        p.found = false;
        return p;
    }

    // if current node is nullptr...
    else {
        p.found = false; 
        p.path = path;
        return p;
    }
}

// Get a path (e.g. "LRLLR") to the leftmost node in the tree with key.

std::string path_to(tree_ptr_t tree, key_t key) {
    // call the helper function with empty string path
    pair p = path_to_helper(tree, key, ""); 
    // program fails if the key was not found in the tree
    assert(p.found);
    // if found, returns the correct path 
    return p.path;
}

// Returns the key of the node at a given path, if the path is valid.
//  If the path is invalid (e.g. out of bounds or just plain gibberish),
//  returns nullptr instead. 

tree_ptr_t node_at(tree_ptr_t tree, std::string path) {
    if (tree == nullptr)
        return nullptr;
    else if (path[0] == 'L')
        return node_at(tree->left_, path.substr(1, path.size()-1));
    else if (path[0] == 'R')
        return node_at(tree->right_, path.substr(1, path.size()-1));
    else if (path[0] == '\0')
        return tree;
    else
        return nullptr;
}
