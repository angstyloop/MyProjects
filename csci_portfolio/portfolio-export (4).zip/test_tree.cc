// Sean Allen
// CSCI HW6

#include "tree.cc"
#include <iostream>

/**********************
This is what my test tree looks like. 
It's a friendly little tree. 

    5
 /     \
2       4
 \     / \
  3   3   7
 /
8

***********************/

int main() {
    // test create_tree
    tree_ptr_t  t = nullptr
            ,   T = create_tree(5,5)
            ;

    // build the tree shown above
    T->left_ = create_tree(
                2
            ,   2
            ,   nullptr
            ,   create_tree(
                        3
                    ,   3
                    ,   create_tree(8,8)
                    ,   nullptr))
            ;
    T->right_ = create_tree(
                4
            ,   4
            ,   create_tree(3,3)
            ,   create_tree(7,7))
            ;

    // test path_to
    assert ( path_to(T, 8) == "LRL" );
    assert ( path_to(T, 3) == "LR" );
    assert ( path_to(T, 7) == "RR" );
    // Uncomment to trigger assert() in path_to
    //path_to(T,88);

    // test node_at
    t = node_at(T, "");
    assert ( t->key_ == 5 );

    t = node_at(T, "LRL");
    assert ( t->key_ == 8 );

    t = node_at(T, "LRLRLRLRL");
    assert ( t == nullptr );

    t = node_at(T, "sdfesdkyufsoidghlr");
    assert ( t == nullptr );

    // test destroy_tree
    destroy_tree(T);
}
