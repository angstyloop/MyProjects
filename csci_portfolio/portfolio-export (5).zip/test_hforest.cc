// SEAN ALLEN
// CSCI 221 HW7
#include "hforest.cc"
#include <iostream>
using tree_ptr_t = std::shared_ptr<const HTree>;
 

#define  LEFT   Direction::LEFT
#define  RIGHT  Direction::RIGHT


/* My test tree looks like this
 *
 *             5
 *           /   \
 *          2     4
 *         / \     \
 *        0   0     1
 *
 *  where the keys are assumed to equal
 *  the values.
 *
 *  My forest is just two of these trees.
 *
 */

// Test HForest methods by printing the path of a node with a particular key value
//  for the example tree above.
int main () {
    // make test tree 1
    HTree   *a1 = new HTree (0, 0)
        ,   *b1 = new HTree (0, 0)
        ,   *c1 = new HTree (2, 2, tree_ptr_t(a1), tree_ptr_t(b1))
        ,   *d1 = new HTree (1, 1)
        ,   *e1 = new HTree (4, 4, tree_ptr_t(nullptr), tree_ptr_t(d1))
        ,   *f1 = new HTree (5, 5, tree_ptr_t(c1), tree_ptr_t(e1))
        ;
    
    // set the path of each node in the tree
    path_t  a1_path {LEFT, LEFT}
        ,   b1_path {LEFT, RIGHT}
        ,   c1_path {LEFT}
        ,   d1_path {RIGHT, RIGHT}
        ,   e1_path {RIGHT}
        ,   f1_path {}
        ;

    a1->set_path(a1_path);
    b1->set_path(b1_path);
    c1->set_path(c1_path);
    d1->set_path(d1_path);
    e1->set_path(e1_path);
    f1->set_path(f1_path);

    // make test tree 2
    HTree   *a2 = new HTree (0, 0)
        ,   *b2 = new HTree (0, 0)
        ,   *c2 = new HTree (2, 2, tree_ptr_t(a2), tree_ptr_t(b2))
        ,   *d2 = new HTree (1, 1)
        ,   *e2 = new HTree (4, 4, tree_ptr_t(nullptr), tree_ptr_t(d2))
        ,   *f2 = new HTree (5, 5, tree_ptr_t(c2), tree_ptr_t(e2))
        ;
    
    // set the path of each node in the tree
    path_t  a2_path {LEFT, LEFT}
        ,   b2_path {LEFT, RIGHT}
        ,   c2_path {LEFT}
        ,   d2_path {RIGHT, RIGHT}
        ,   e2_path {RIGHT}
        ,   f2_path {}
        ;

    a2->set_path(a2_path);
    b2->set_path(b2_path);
    c2->set_path(c2_path);
    d2->set_path(d2_path);
    e2->set_path(e2_path);
    f2->set_path(f2_path);

    // make a forest with two trees
    HForest forest;
    for (auto r : {f1, f2})
        forest.add_tree(tree_ptr_t(r));

    // print the size of the forest
    std::cout << forest.size() << std::endl;


}
