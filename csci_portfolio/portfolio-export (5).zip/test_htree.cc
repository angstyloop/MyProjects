// SEAN ALLEN
// CSCI 221 HW7

#include "htree.cc"
#include <iostream>
#define  LEFT   Direction::LEFT
#define  RIGHT  Direction::RIGHT

using tree_ptr_t = std::shared_ptr<const HTree>;

/* My test tree looks like this
 *
 *             5
 *           /   \
 *          2     4
 *         / \     \
 *        0   0     1
 *
 *  where the keys are assumed to equal
 *  the values.
 *
 */

// Test path_to by printing the path of a node with a particular key value
//  for the example tree above.
int main () {
    // make a test tree
    HTree   *a = new HTree (0, 0)
        ,   *b = new HTree (0, 0)
        ,   *c = new HTree (2, 2, tree_ptr_t(a), tree_ptr_t(b))
        ,   *d = new HTree (1, 1)
        ,   *e = new HTree (4, 4, tree_ptr_t(nullptr), tree_ptr_t(d))
        ,   *f = new HTree (5, 5, tree_ptr_t(c), tree_ptr_t(e))
        ;
    
    // set the path of each node in the tree
    path_t  a_path {LEFT, LEFT}
        ,   b_path {LEFT, RIGHT}
        ,   c_path {LEFT}
        ,   d_path {RIGHT, RIGHT}
        ,   e_path {RIGHT}
        ,   f_path {}
        ;

    a->set_path(a_path);
    b->set_path(b_path);
    c->set_path(c_path);
    d->set_path(d_path);
    e->set_path(e_path);
    f->set_path(f_path);

    // get the path of a node
    HTree*& root = f;

    // change this value to find different keys
    int key = 4;
    
    path_t temp_path = root->path_to(key);
    
    for ( auto x : temp_path ) {
        if (x == LEFT)
            std::cout << "left" << " ";
        if (x == RIGHT)
            std::cout << "right" << " ";
    }
    std::cout << std::endl;

}
