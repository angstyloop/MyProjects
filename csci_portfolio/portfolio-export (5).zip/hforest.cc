 // SEAN ALLEN
 // CSCI 221 HW7
#include "hforest.hh"
using tree_ptr_t = std::shared_ptr<const HTree>;
using hf = HForest;

int hf::size () {
    return roots.size();
} 

void hf::add_tree(tree_ptr_t root) {
    roots.insert(roots.begin(), root);
    std::make_heap(roots.begin(), roots.end(), compare_trees);
}

tree_ptr_t hf::pop_tree() {
    roots.erase(roots.begin());
    std::make_heap(roots.begin(), roots.end(), compare_trees);
    return *roots.begin();
}
