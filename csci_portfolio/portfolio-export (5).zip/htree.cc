#include "htree.hh"
using ht = HTree;

// Pretty straightforward.
//
ht::HTree (int key, uint64_t value, tree_ptr_t left, tree_ptr_t right) {
    key_ = key;
    value_ = value;
    left_ = left;
    right_ = right;
}

// Since we're using shared_ptr, we need to call the HTree destructor explicitly
//  on the left and right nodes instead of using delete. (shared_ptrs cant be deleted)
//
ht::~HTree () {
    for ( auto ptr : {left_, right_} )
        if (ptr!=nullptr)
            ptr->~HTree();
}
//ht::~HTree () {}

// Generic getter methods.
//
int ht::get_key () const {
    return key_;
}

uint64_t ht::get_value() const {
    return value_;
}

path_t ht::get_path() const {
    return path_;
}

// a setter method for the path 
void ht::set_path(path_t path) {
    path_ = path;
}

// Pretty straightforward. Note the usage of :: when referring to enum class members.
ht::tree_ptr_t ht::get_child (Direction dir) const {
    switch (dir) {
        case Direction::LEFT:
            return left_;
        case Direction::RIGHT:
            return right_;
    }
}

// Return a path to the leftmost node in the tree with matching key.
//
//  Note:   Instead of building the path as I go along, I assume the path
//          to each node is stored in the node itself.
//
//  Note:   The root has a path that is the empty list. 
//
path_t ht::path_to (int key) const {

    // First check if the HTree node calling this method
    //  has the key we're looking for.
    //
    if (key_ == key)
        return path_;

    // Define a temp variable to hold the result of recursive
    //  calls to path_to.
    //
    path_t temp_path;

    // If there is a left child, and the path returned by
    //  a recursive call to the path_to method of the left
    //  child is not the empty list, then the subtree rooted
    //  at the left child contains the key we're looking for,
    //  so we return said path.
    //
    if ( left_ != nullptr ) {
        temp_path = left_->path_to(key);
        if (temp_path.size() != 0)
            return temp_path;
    }

    // We'll get here if the left subtree doesn't contain the correct key.
    //  In that case we do the same thing as we did for the left subtree,
    //  but to the right subtree this time.
    //
    if ( right_ != nullptr ) {
        temp_path = right_->path_to(key);
        if (temp_path.size() != 0)
            return temp_path;
    }

    // If we made it this far in the program AND we're back at the root node,
    //  which is the only node with path size zero, then the entire tree doesn't 
    //  contain the key we want, so we should fail with an assert() like the 
    //  problem statement says.
    //
    if ( path_.size() == 0 )
        assert(false);

    // If we made it this far and we're NOT at the root node, then we return
    //  an empty list to indicate that the subtree rooted at this node does
    //  not contain the key we want.
    //
    temp_path.clear();
    return temp_path;
}
