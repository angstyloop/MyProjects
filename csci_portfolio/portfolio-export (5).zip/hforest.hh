 // SEAN ALLEN
 // CSCI 221 HW7
#include "htree.cc"
#include <vector>

using tree_ptr_t = std::shared_ptr<const HTree>;

bool compare_trees(tree_ptr_t t1, tree_ptr_t t2) {

    return t1->get_value() < t2->get_value();
}

class HForest {
    std::vector<tree_ptr_t> roots;
    public:
        HForest () {}
        ~HForest () {}
        int size();
        void add_tree(tree_ptr_t);
        tree_ptr_t pop_tree();
};
