// Sean Allen
// CSCI 221 HW 11: TSP part 3
//
#include "tournament_deme.hh"

// override select_parent. pairs of members fight in a tournament until only one remains.
//  the return value is a pointer to the winning chromosome.
Chromosome* TournamentDeme::select_parent() {

    // generate an exponent p, such that 2^p is smaller than the population size
    std::uniform_int_distribution<int> dist (0, int(log2(pop_.size())));
    int p = dist(generator_);

    // now redefine p = 2^p
    p = pow(2, p); 
    
    // to randomly select p members of the population, we shuffle pop
    //  and then use the first p members.
    std::shuffle(pop_.begin(), pop_.end(), generator_);

    // make a new temporary vector "competitors". we'll whittle it down with competition.
    //  competitors starts off containing p members.
    std::vector<Chromosome*>::const_iterator first = pop_.begin();
    std::vector<Chromosome*>::const_iterator last = pop_.begin() + p - 1;
    std::vector<Chromosome*> competitors(first, last);

    // make a new temporary vector "new_competitors".
    std::vector<Chromosome*> new_competitors;

    // while competitors contains more than just one member
    //  loop through competitors two at a time, pushing the fittest into new_competitors. 
    while (competitors.size()>1){   
        for (int i=0; i<p; i=i+2) {
            // case: even index element has greater fitness
            if (competitors[2*i]->get_fitness() > competitors[2*i+1]->get_fitness())
                new_competitors.push_back(competitors[2*i]);
            // case: odd index element has greater fitness
            else
                new_competitors.push_back(competitors[2*(i+1)]);
        }

        // replace competitors with new ones
        competitors = new_competitors;

        //empty new_competitors so we can use it next iteration
        new_competitors.clear();

        // change p to new p, which is half of the old
        p = p / 2;
    }

    // now the only member of competitors is the winner. return that pointer.
    return(competitors[0]);

}
