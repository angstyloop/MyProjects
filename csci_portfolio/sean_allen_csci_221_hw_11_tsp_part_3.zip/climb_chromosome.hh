#include "part2-solution/chromosome.cc"

class ClimbChromosome : public Chromosome { 
    public:
        // ctr
        ClimbChromosome (const Cities* cities) : Chromosome (cities) {}

        // dtr
        virtual ~ClimbChromosome() {}

        // mutate
        virtual void mutate();

        // clone
        virtual ClimbChromosome* clone() const;
};
