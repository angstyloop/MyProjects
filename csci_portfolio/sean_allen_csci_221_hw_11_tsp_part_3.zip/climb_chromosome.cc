// Sean Allen
// CSCI 221 HW 11 : TSP Project 3
#include "climb_chromosome.hh"

// overriding clone()
ClimbChromosome* ClimbChromosome::clone() const {
    return new ClimbChromosome(*this);
}

// overriding mutate()
//
// notes: Instead of making two copies of the Chromosome, permutating them, and then selecting
//          the fittest of the three, I instead used one Chromosome and undid the swaps as necessary.
//          this is a little more cumbersome to write and read, but technically faster.
//
void ClimbChromosome::mutate() {
    // fitness values
    double f_0, f_1, f_2;

    // size of order_
    const int& N = order_.size();

    // get the unpermuted Chromosome fitness
    f_0 = get_fitness();

    // swap a random element with the one before it (wrapping around)
    std::uniform_int_distribution<int> dist (0, N-1);
    int p = dist(generator_);
    std::swap(order_[p], order_[p==0? N-1 : p-1]);

    // get the new fitness
    f_1 = get_fitness();

    // undo the swap so we can permute the original 
    std::swap(order_[p], order_[p==0 ? N-1 : p-1]);

    // swap a random element with the one before it (wrapping around)
    p = dist(generator_); 
    std::swap(order_[p], order_[p%(N-1)]);
    f_2 = get_fitness(); 

    // depending on which f-value is the max, we'll have to swap differently
    //  to get back to the version of the chromosom we want

    // if f_0 is the max...
    if ( f_0>=f_1 && f_0>=f_2 ) {    
        // undo the last swap we did (the one we did to get f_2)
        std::swap(order_[p], order_[p%(N-1)]);
        //now order_ is the way it started, and we're done
    }

    // if f_1 is the max...
    else if ( f_1>=f_0 && f_1>=f_2 ) {
        // undo the last swap we did (the one we did to get f_2)
        std::swap(order_[p], order_[p%(N-1)]);
        // redo the first swap we did (the one we did to get f_1)
        std::swap(order_[p], order_[p==0? N-1 : p-1]);
    }
    
    // otherwise f_2 is the max and Chromosome is the way we want it already

}

