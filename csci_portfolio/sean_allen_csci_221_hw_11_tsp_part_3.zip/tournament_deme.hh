// Sean Allen
// CSCI 221 HW 11: TSP part 3
//
#include "deme.cc"

class  TournamentDeme : public Deme {
    public:
    //ctr
    TournamentDeme(const Cities* cities_ptr, unsigned pop_size, double mut_rate) 
        : Deme(cities_ptr, pop_size, mut_rate) {}
    // virtual dtr
    virtual ~TournamentDeme() {}
    // override select_parent
    virtual Chromosome* select_parent();
};
