// Sean Allen
// CSCI 221 HW 9 TSP Part 1

#include "cities.hh"
#include <iostream>
#include <cmath>
#include <random>



// Process .tsv file line by line, storing coordinate pairs as you go.
std::istream& Cities::operator>> (std::istream& istrm) {

    std::string line;
    coord_t coord;
    char c = istrm.get();

    while (c!=EOF) {
        coord.first = c;
        istrm.ignore();
        coord.second = istrm.get();
        istrm.ignore();
        this->coords.push_back(coord);
        this->perm.push_back(coords.size()-1);
        c = istrm.get();
    } 

    return istrm;
}

std::ostream& Cities::operator<< (std::ostream& ostrm) {

    for (auto i : this->perm) 
        ostrm << coords[i].first
              << '\t'
              << coords[i].second
              << '\n'
              ;

    return ostrm;
}

double Cities::total_path_distance(permutation_t p) const {
    
    // p must have the same size as coords
    assert (this->coords.size() == p.size());

    // square distance 
    double d2 = 0; 

    // a constant for clarity
    const unsigned n = this->coords.size();

    // Loop through coordinates in the order set by permutation, adding
    //  sum of each square coordinate difference as you go.
    //  Note that mod makes sure we get the last->first distance.
    for (int i=0; i<n; i = (i+1)%n) {

        // clarity constants
        const double& x0 = coords[p[i]].first
                    , x1 = coords[p[i+1]].first
                    , y0 = coords[p[i]].second
                    , y1 = coords[p[i+1]].second
                    ;

        // add the square coordinate differences to running total square distance
        d2 += pow(x1-x0, 2) + pow(y1-y0, 2);
    }

    // take square root of square distance to get distance
    return sqrt(d2);
}

// reorder the internal order of cities in  a cities object according to its permutation
Cities Cities::reorder() {
    std::vector<coord_t> old_coords = this->coords;
    for (int i=0; i<coords.size(); ++i)
        coords[i] = old_coords[this->perm[i]];
    return *this;
}

// helpful function swaps two elements in a permutation_t
void swap (Cities::permutation_t p, unsigned int a, unsigned int b) {
    int temp = a;
    a = b;
    b = temp;
}

// generate [1, ... , n] and then shuffle it with fisher-yates
Cities::permutation_t random_permutation(int n) {

    // new permutation of length n
    Cities::permutation_t p (n);

    // make a random number generator
    std::random_device seed;
    std::default_random_engine gen(seed());

    for (int i=0; i<n; ++i)
        p[i] = i;

    for (int i=n-1; i>0; --i) {

        // select interval [0,i] for random distribution
        std::uniform_int_distribution<int> dist(0, i);

        // pick a random int from [0, i]
        int random_i = dist(gen);

        // swap element i and the random one
        swap(p, i, random_i);
    }

    // return the shuffled permutation_t
    return p;
}

int main() {

    Cities cities;
    Cities::permutation_t rand_perm;
    unsigned min_distance
        ,    new_distance
        ;

    // read in .tsv file from stdin. just use cat on command line and pipe it.
    cities << (std::cin);

    // initialize min_distance
    min_distance = cities.total_path_distance(cities.perm);
   
    // 10000 iterations
    for (int i = 0; i<10000; ++i) {
        // generate random permutation
        rand_perm = random_permutation(cities.perm.size());

        // computed distance of path associated with rand_perm
        new_distance = cities.total_path_distance(rand_perm);

        // if the distance computed is less than the smallest
        //  distance seen so far (min_distance), replace the old
        //  perm member of cities and change min_distance to new_distance.
        if ( new_distance < min_distance) {
            cities.perm = rand_perm;
            std::cout << i << '\t' << new_distance << std::endl;
            min_distance = new_distance;
        }
    }
    return 0;
}




