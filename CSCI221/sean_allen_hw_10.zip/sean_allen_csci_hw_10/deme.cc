//Sean Allen
/*
 * Declarations for Deme class to evolve a genetic algorithm for the
 * travelling-salesperson problem.  A deme is a population of individuals.
 */

#include "chromosome.hh"
#include "deme.hh"

// Generate a Deme of the specified size with all-random chromosomes.
// Also receives a mutation rate in the range [0-1].
Deme::Deme(const Cities* cities_ptr, unsigned pop_size, double mut_rate)
{
  // Add your implementation here

  // The Chromosome ctr actually already randomizes its order_ upon initialization,
  //    so we can just make a bunch of pointers with new and stick them in pop_
  while (pop_size-- > 0)
      pop_.push_back(new Chromosome(cities_ptr));
}

// Clean up as necessary
Deme::~Deme()
{
    // Add your implementation here

    // Since we called "new", we have to call delete on each ptr in pop_
    for (auto p : pop_)
        delete p;

}

// Evolve a single generation of new chromosomes, as follows:
// We select pop_size/2 pairs of chromosomes (using the select() method below).
// Each chromosome in the pair can be randomly selected for mutation, with
// probability mut_rate, in which case it calls the chromosome mutate() method.
// Then, the pair is recombined once (using the recombine() method) to generate
// a new pair of chromosomes, which are stored in the Deme.
// After we've generated pop_size new chromosomes, we delete all the old ones.
void Deme::compute_next_generation()
{
    // Add your implementation here
    
    // Declare the new population
    std::vector<Chromosome*> new_pop;
    
    // popsize/2 iterations
    for (int it=0; it<pop_.size(); ++it) {

        // to select two parents at random, first generate two random indices 
        std::uniform_int_distribution<int> dist (0, pop_.size()-1);
        int     i = dist(generator_)
            ,   j = dist(generator_)
            ;

        // make sure i != j
        while (i==j)
            j = dist(generator_);

        // then roll to mutate for each parent
        std::uniform_real_distribution<double> rdist (0, 1);
        for (auto r : {i, j})
            if (rdist(generator_) < mut_rate_)
                pop_[r]->mutate();

        // make babes
        std::pair<Chromosome*, Chromosome*> 
            babes = pop_[i]->recombine(pop_[j]);

        // send them to new_pop
        new_pop.push_back(babes.first);
        new_pop.push_back(babes.second);
    }

    // delete old population
    for (auto chrom_ptr : pop_)
        delete chrom_ptr;

    // ... and replace with new pop
    pop_ = new_pop;

    // Note: the population size will decrease by one for odd pop_size, due to
    //  floor division in the above while-loop condition.
}

// Return a copy of the chromosome with the highest fitness.
const Chromosome* Deme::get_best() const
{
    // Add your implementation here

    // initialize vars
    Chromosome* fit_chromosome_ptr = nullptr;
    double highest_fitness = 0
        ,   temp_fitness   = 0
        ;
    const Cities* cities_ptr = pop_[0]->get_cities_ptr();

    // loop through pop_ keeping track of the sexiest animal
    for (auto x: pop_) {
        temp_fitness = x->get_fitness();
        if (temp_fitness > highest_fitness) {
            highest_fitness = temp_fitness;
            fit_chromosome_ptr = x; 
        }
    }
        
   // initialize the copy
   Chromosome* fit_chromosome_copy_ptr = new Chromosome (cities_ptr);      
   
   // set the ordering of the copy  (i wrote getter/setter methods in chromosome.hh)
   fit_chromosome_copy_ptr->set_ordering(fit_chromosome_ptr->get_ordering());

   return fit_chromosome_copy_ptr;
}

// Randomly select a chromosome in the population based on fitness and
// return a pointer to that chromosome.
Chromosome* Deme::select_parent()
{
  // Add your implementation here

    // Roulette Wheel selection

    // sum the fitnesses
    double sum = 0;
    for (auto chrom_ptr : pop_)
        sum += chrom_ptr->get_fitness();

    // generate random number between 0 and $sum
    std::uniform_int_distribution<int> dist (0, sum);
    int rand_int = dist(generator_);

    // loop through the population, adding fitnesses until
    //  the running total surpasses rand_int. whichever chromosome
    //  pushed the total over the limit is the winner.

    sum = 0;
    Chromosome* winner_ptr = nullptr;

    for (auto chrom_ptr : pop_) {
        sum += chrom_ptr->get_fitness();
        if (sum > rand_int) {
            winner_ptr = chrom_ptr;
            break;
        }
    }

    return winner_ptr;
}
