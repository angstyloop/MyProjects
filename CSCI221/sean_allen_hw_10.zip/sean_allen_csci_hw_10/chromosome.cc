//Sean Allen
//
/*
 * Implementation for Chromosome class
 */

#include <algorithm>
#include <cassert>
#include <random>
#include <cmath>

#include "chromosome.hh"

//////////////////////////////////////////////////////////////////////////////
// Generate a completely random permutation from a list of cities
//
// Looks like the ctr doesnt need anything new from me.
//
Chromosome::Chromosome(const Cities* cities_ptr)
    :   cities_ptr_(cities_ptr)
    ,        order_(random_permutation(cities_ptr->size()))
    ,    generator_(rand())
{
  assert(is_valid());
}

//////////////////////////////////////////////////////////////////////////////
// Clean up as necessary
//
// Again, this is all good. permutation_t is a vector so it cleans itself up.
// Chromosome isn't in charge of deleting the Cities object.
// 
Chromosome::~Chromosome()
{
  assert(is_valid());
}

//////////////////////////////////////////////////////////////////////////////
// Perform a single mutation on this chromosome
void
Chromosome::mutate()
{
    // Add your implementation here

    // for dbuggin'
    assert(is_valid());

    // get two random indices
    std::uniform_int_distribution<int> 
            dist (0, order_.size()-1)
        ;
    int     i = dist(generator_)
        ,   j = dist(generator_)
        ;

    // make sure i != j
    while (i==j)
        j = dist(generator_);
    
    // swap 'em'
    auto temp = order_[i];
    order_[i] = order_[j];
    order_[j] = temp;

}

//////////////////////////////////////////////////////////////////////////////
// Return a pair of offsprings by recombining with another chromosome
// Note: this method allocates memory for the new offsprings
std::pair<Chromosome*, Chromosome*>
Chromosome::recombine(const Chromosome* other)
{
    assert(is_valid());
    assert(other->is_valid());

    // genes should probably have the same length
    assert(this->order_.size() == other->order_.size());

    // Add yer implementation here lassie

    // declare the wee lil' babes
    std::pair<Chromosome*, Chromosome*>
        babes;

    //random indices
    std::uniform_int_distribution<int> dist (0, order_.size()-1);
    int     i = dist(generator_)
        ,   j = dist(generator_)
        ;


    // do it both ways 
    babes.first = create_crossover_child(this, other, std::min(i, j), std::max(i, j));
    babes.second = create_crossover_child(other, this, std::min(i, j), std::max(i, j));



}

//////////////////////////////////////////////////////////////////////////////
// For an ordered set of parents, return a child using the ordered crossover.
// The child will have the same values as p1 in the range [b,e),
// and all the other values in the same order as in p2.
Chromosome*
Chromosome::create_crossover_child(const Chromosome* p1, const Chromosome* p2,
                                   unsigned b, unsigned e) const
{
  Chromosome* child = p1->clone();

  // We iterate over both parents separately, copying from parent1 if the
  // value is within [b,e) and from parent2 otherwise
  unsigned i = 0, j = 0;

  for ( ; i < p1->order_.size() && j < p2->order_.size(); ++i) {
    if (i >= b and i < e) {
      child->order_[i] = p1->order_[i];
    }
    else { // Increment j as long as its value is in the [b,e) range of p1
      while (p1->is_in_range(p2->order_[j], b, e)) {
        ++j;
      }
      assert(j < p2->order_.size());
      child->order_[i] = p2->order_[j];
      j++;
    }
  }

  assert(child->is_valid());
  return child;
}

// Return a positive fitness value, with higher numbers representing
// fitter solutions (shorter total-city traversal path).
double
Chromosome::get_fitness() const
{
    // Add your implementation here

    // utilize total_path_distance from cities.hh; call it "d"
    double d = cities_ptr_->total_path_distance(order_);

    // use exponential function of negative distance
    return exp(-d);
}

// A chromsome is valid if it has no repeated values in its permutation,
// as well as no indices above the range (length) of the chromosome.
// We implement this check with a sort, which is a bit inefficient, but simple
bool
Chromosome::is_valid() const
{
    // Add your implementation here

    // declare the future bool return value
    bool valid = true;

    // Copy the permutation
    Cities::permutation_t sorted_order (order_);
  
    // sort the copy
    std::shuffle(std::begin(sorted_order), std::end(sorted_order), generator_);

    // make sure the last (and largest) element is less than the lenght of the permutation
    if (sorted_order.back() > sorted_order.size()) {
        valid = false;
    }

    // if that's all good, loop through the permutation, 
    //  checking each entry against the previous entry
    //  to see if any entries are the same.
    else for (int i=1; i<sorted_order.size(); ++i)
        if (sorted_order[i]==sorted_order[i-1]) {
            valid = false;
            break;
        }

    // return result "valid"
    return valid;     
}

// Find whether a certain value appears in a given range of the chromosome.
// Returns true if value is within the specified the range specified
// [begin, end) and false otherwise.
bool
Chromosome::is_in_range(unsigned value, unsigned begin, unsigned end) const
{
    // Add your implementation here

    // check each value from order_[begin] to order_[begin-1]]
    while (begin!=end)
        if (order_[begin]==value)
            return true; //cool, found it
        else ++begin;    // that's not it, thank u next

    // control reaches this point only if $value wasn't in the range
    return false;

}
