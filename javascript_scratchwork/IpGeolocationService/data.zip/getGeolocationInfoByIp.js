const Reader = require('@maxmind/geoip2-node').Reader

module.exports = function (ip) {
    return Reader.open('./GeoLite2-City.mmdb').then(reader => {
        const res = reader.city(ip)
        console.log(res)
        return res
    }) 
}

